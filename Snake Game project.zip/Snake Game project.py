#import modules
import turtle
import random
import time

delay = 0.1
score = 0
high_score = 0

# creating a window screen
wn = turtle.Screen()
wn.title("Snake Game")
wn.bgcolor("#7b9432")
wn.setup(width=600, height=600)
wn.tracer(0) # for the update drawing
try:
    wn.cv._rootwindow.resizable(False, False)
except Exception:
    pass       # so that the user can't change the sizes

#head of the snake
head = turtle.Turtle()
head.shape("square")
head.color("#0047ab")
head.penup()       #stop drawing lignes when moving
head.speed(0)
head.goto(0, 0)   # coordinates of start
head.direction = "stop"

# food
food = turtle.Turtle()
colors = random.choice(["#ff2c2c" , "#ffce1b" , "#677d25"])
food.color (colors)
food.shape("circle")
food.penup()
food.speed(0)
food.goto(0,100)

# top bar (header area)
header = turtle.Turtle()
header.hideturtle()
header.penup()
header.pensize(3)
header.color("black")

# header UI
header.goto(-300, 300)
header.pendown()
header.goto(300, 300)
header.goto(300, 230)
header.goto(-300, 230)
header.goto(-300, 300)
header.penup()

# score text inside the header
pen = turtle.Turtle()
pen.hideturtle()
pen.penup()
pen.color("black")
pen.goto(-280, 260)
pen.write("Score: 0   High score: 0", align="left", font=("Courier", 20, "normal"))

# update score display (use this whenever score/high_score change)
def update_score_display():
    pen.clear()
    pen.write("Score: {}   High score: {}".format(score, high_score),
              align="left", font=("Courier", 20, "normal"))

# key directions
def go_up():
    if head.direction != "down":
        head.direction = "up"

def go_down():
    if head.direction != "up":
        head.direction = "down"

def go_left():
    if head.direction != "right":
        head.direction = "left"

def go_right():
    if head.direction != "left":
        head.direction = "right"


def move():
    if head.direction == "up":
        y = head.ycor()
        head.sety(y + 20)
    if head.direction == "down":
        y = head.ycor()
        head.sety(y - 20)
    if head.direction == "left":
        x = head.xcor()
        head.setx(x - 20)
    if head.direction == "right":
        x = head.xcor()
        head.setx(x + 20)

# key binding
wn.listen()
wn.onkey(go_up, "w")
wn.onkey(go_down, "s")
wn.onkey(go_left, "a")
wn.onkey(go_right, "d")

segments =[]
#main game play
while True:
    wn.update()
    # checking for head collection with borders
    if (
            head.xcor() < -270
            or head.xcor() > 270
            or head.ycor() < -270
            or head.ycor() > 200
    ):  # reset position & segments (loss)
        time.sleep(2)
        # save high score before reset
        if score > high_score:
            high_score = score

        head.goto(0, 0)
        head.direction = "stop"

        for segment in segments:  # reset segments
            segment.hideturtle()
        segments.clear()

        score = 0  # reset the score
        delay = 0.1
        update_score_display()


    # Checking for head collisions with food
    if head.distance(food) < 20:
        x = random.randint(-270, 270)
        y = random.randint(-270, 200)
        food.goto(x, y)

        # change food color at the moment of eating
        new_color = random.choice(["#ff2c2c" , "#ffce1b" , "#677d25"])
        food.color(new_color)
        food.shape("circle")

        # Adding segment
        new_segment = turtle.Turtle()
        new_segment.shape("circle")
        new_segment.color("green")  # tail colour
        new_segment.speed(0)
        new_segment.penup()
        segments.append(new_segment)
        delay -= 0.0001  # increase game difficulty
        score += 10
        if score > high_score:
            high_score = score
        update_score_display()


    # Shifting all snake body (segments[]) then move the (head)
    for index in range(len(segments) - 1, 0, -1):
        x = segments[index - 1].xcor()
        y = segments[index - 1].ycor()
        segments[index].goto(x, y)
    if len(segments) > 0:
        x = head.xcor()
        y = head.ycor()
        segments[0].goto(x, y)
    move()

    # Checking for head collisions with body segments
    for segment in segments:
        if segment.distance(head) < 20:
            time.sleep(2)
            # save high score before reset
            if score > high_score:
                high_score = score

            head.goto(0, 0)
            head.direction = "stop"

            # don't change food color here (we want that only on eat)
            for segment in segments:
                segment.hideturtle()
            segments.clear()
            score = 0
            delay = 0.1
            update_score_display()
            break
    time.sleep(delay)
